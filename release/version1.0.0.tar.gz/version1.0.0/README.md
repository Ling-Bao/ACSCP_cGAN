# production

#### 0. have dropout or no dropout
```
modify: product.py
line: 41, 42 and 282, 283

have dropout model: g_large_model_412
no dropout model: g_large_model_414
```
#### 1. get crowd counting
```
python product.py
```

#### 2. get real crowd counting
```
cd lib
python utils.py
```